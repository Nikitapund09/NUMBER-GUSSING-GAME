
public class GuessTheNumber {

}
